package com.example.firebaselogin

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class HomeActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var editName: EditText
    private lateinit var editAge: EditText
    private lateinit var editDepartment: EditText
    private lateinit var btnSave: Button
    private lateinit var btnRetrieve: Button
    private lateinit var txtUserData: TextView
    private lateinit var btnDelete: Button
    private lateinit var btnUpdate: Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        auth = FirebaseAuth.getInstance()
        val dbRef = FirebaseDatabase.getInstance().getReference("Users")

        // Initialize views
        editName = findViewById(R.id.editName)
        editAge = findViewById(R.id.editAge)
        editDepartment = findViewById(R.id.editDepartment)
        btnSave = findViewById(R.id.btnSave)
        btnRetrieve = findViewById(R.id.btnRetrieve)
        txtUserData = findViewById(R.id.txtUserData)
        btnDelete = findViewById(R.id.btnDelete)
        btnUpdate = findViewById(R.id.btnUpdate)



        btnSave.setOnClickListener {
            val name = editName.text.toString().trim()
            val age = editAge.text.toString().trim()
            val dept = editDepartment.text.toString().trim()

            if (name.isEmpty() || age.isEmpty() || dept.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val uid = auth.currentUser?.uid ?: return@setOnClickListener
            val user = mapOf("name" to name, "age" to age, "department" to dept)

            dbRef.child(uid).setValue(user)
                .addOnSuccessListener {
                    Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
                    clearFields()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error saving", Toast.LENGTH_SHORT).show()
                }
        }

        btnRetrieve.setOnClickListener {
            val uid = auth.currentUser?.uid ?: return@setOnClickListener

            dbRef.child(uid).get().addOnSuccessListener { snapshot ->
                val name = snapshot.child("name").value
                val age = snapshot.child("age").value
                val dept = snapshot.child("department").value

                txtUserData.text = "Name: $name\nAge: $age\nDepartment: $dept"
            }.addOnFailureListener {
                Toast.makeText(this, "Error retrieving", Toast.LENGTH_SHORT).show()
            }
        }

        btnDelete.setOnClickListener {
            val uid = auth.currentUser?.uid ?: return@setOnClickListener

            dbRef.child(uid).removeValue()
                .addOnSuccessListener {
                    Toast.makeText(this, "Data deleted", Toast.LENGTH_SHORT).show()
                    txtUserData.text = "User Data will appear here"
                    clearFields()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error deleting data", Toast.LENGTH_SHORT).show()
                }
        }

        btnUpdate.setOnClickListener {
            val name = editName.text.toString().trim()
            val age = editAge.text.toString().trim()
            val dept = editDepartment.text.toString().trim()

            if (name.isEmpty() || age.isEmpty() || dept.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val uid = auth.currentUser?.uid ?: return@setOnClickListener
            val updatedData = mapOf("name" to name, "age" to age, "department" to dept)

            dbRef.child(uid).updateChildren(updatedData)
                .addOnSuccessListener {
                    Toast.makeText(this, "Updated", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error updating", Toast.LENGTH_SHORT).show()
                }
        }


    }

    private fun clearFields() {
        editName.text.clear()
        editAge.text.clear()
        editDepartment.text.clear()
    }
}
